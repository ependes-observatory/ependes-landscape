Épendes Landscape for Stellarium
================================

Description
-----------

This high resolution landscape shows the panorama visible from the
roof of the Observatoire Astronomique Robert A. Naef d'Épendes,
near Fribourg, Switzerland.


Files
-----

This file (readme.txt) should have come in a zip file with some others
Here is a listing of all the files which should be in the zip file:

  ependes/readme.txt (this file)
  ependes/landscape.ini
  ependes/ependes.png


Installation & Use
-----------------

Unzip the zip file in the <user_directory>/landscapes directory.
The location varies depending on your operating system.  See the 
Stellarium User Guide for per-platform details.

Once you have installed the landscape, open Stellarium and go to the
configuration dialog.  Select the landscapes tab, and select the landscape
from the list of available landscapes.


Credits
-------

Landscape creator: Nicolas Martignoni


License
-------

Copyright (C) 2006-2007 Nicolas Martignoni
These files are provided under the terms of the GPL.

